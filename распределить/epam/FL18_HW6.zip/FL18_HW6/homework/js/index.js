function visitLink(path) {
	//your code goes here
}

function viewResults() {
	//your code goes here
}
