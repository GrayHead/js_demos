function reverseNumber(num) {

}

function forEach(arr, func) {

}

function map(arr, func) {

}

function filter(arr, func) {

}

function getAdultAppleLovers(data) {

}

function getKeys(obj) {

}

function getValues(obj) {

}

function showFormattedDate(dateObj) {

}
